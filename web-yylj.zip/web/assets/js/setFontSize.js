/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var hn = 3;
var textStyle;
//var verticalAlign=['baseline','super','sub','top','middle','bottom','text-top','text-bottom','central','calc','auto'];
var verticalAlign = ['super', 'top', 'text-top', 'sub', 'bottom', 'text-bottom', 'central', 'baseline'];
var fontFamily = ['华文中宋', '隶书', '方正舒体', 'serif', 'sans-serif', 'cursive', 'fantasy', 'monospace', 'inherit', 'initial'];
var align = ['left', 'right', 'center', 'justify', 'start', 'end'];
var hidenotice = true;
var timestatu = 0;    //0:initial, 1:normal, 2:pause, 3:back, 4:b pause; 
var time;
var timeout;    //多线程; 
var trybutton = ':\n';
var flying=null;
var px0=5,px1=70,py0=40,py1=80,px=px0,py=py0;
var dx=1,dy=1;

String.prototype.timeFormat = function (date) {
    var y = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
    return y;
};

function fontsize(size) {
    var fs = document.getElementById("fontsize");
    if (size == 1 && hn > 1) {        //-
        hn--;
//        dd=document.getElementById("dd");
//        dd.innerHTML="<span>O</span>";
//        x=Math.floor(Math.random()*600);
//        y=Math.floor(Math.random()*600);
//        ds.firstElementChild.style.top=x+"px";
//        ds.firstElementChild.style.left=y+"px";
    } else if (size == 0 && hn < 9) {     //+
        hn++;
    }
    fs.innerHTML = "<h" + hn + ">岳阳楼记嶽陽樓(h" + hn + ")</h" + hn + ">";
}

function chooseColor() {
    var c = document.getElementById("setColor");
    var ccc = document.getElementById("cccs");
    c.style = "color:" + ccc.value + ";background-color:white;font-family:隶书;font-style:normal;";
}

function setTextStyle() {
    var ts = document.getElementById('textStyle');
    var va = document.getElementsByName("textVerticalAlign")[0];
    var sc = document.getElementsByName("setColor");
    var al = document.getElementsByName("textAlign")[0];
    var tf = document.getElementsByName("textFont")[0];
    var fs = document.getElementById("fontSize").value;
    var color;
    if (isNaN(fs) || fs < 0 || fs > 50) {
        fs = 'initial;';
    } else {
        fs = parseInt(fs) + 'px;';
    }
    if (sc[0].checked) {
        color = document.getElementsByName("ccc");
        color = 'RGB(' + color[0].value + '%,' + color[1].value + '%,' + color[2].value + '%)';
    } else if (sc[1].checked) {
        color = document.getElementById("cccs");
        color = color.value;
    }
    textStyle = "vertical-align:" + va.value + ";color:" + color + ";font-family:" + tf.value
            + ";text-align:" + al.value + ";font-size:" + fs;
    ts.style = textStyle;
    var tss = document.getElementById("textSample");
    tss.style = textStyle;
}

function timerun() {
    timeout && clearTimeout(timeout);
    var date;
    time.setTime(time.getTime() - 1000 * (timestatu - 2));
    date = time.toDateString();
    var st = document.getElementById("showTime");
    st.innerHTML = date + '<br>' + "".timeFormat(time);    //t.toLocaleString() ;
    timeout = setTimeout("timerun()", 1000);
}
function setTime() {
    var button = document.getElementById("timeButton");
    switch (timestatu) {
        case 0:
            timestatu = 1;
            button.value = '||';
            time = new Date();
            timerun();
            break;
        case 1:
            timestatu = 2;
            button.value = '|>';
            timeout && clearTimeout(timeout);
            break;
        case 2:
            timestatu = 1;
            button.value = '||';
            timerun();
            break;
        case 3:
            timestatu = 4;
            button.value = '<|';
            timeout && clearTimeout(timeout);
            break;
        case 4:
            timestatu = 3;
            button.value = '||';
            timerun();
            break;
    }
}
function setTime2() {
    var button = document.getElementById("timeButton");
    if (timestatu === 2 || timestatu === 4) {
        timestatu = (timestatu + 1) % 4;
        button.value = '||';
        timerun();
    } else if (timestatu === 1 || timestatu === 3) {
        timestatu = 0;
        setTime();
    }
}

function hideNotice() {
    var n = document.getElementById("notice");
    n.hidden = hidenotice;
    hidenotice = !hidenotice;
}

function tryButton(tb) {
    trybutton += tb + '\n';
    if (tb === 'ondblclick') {
        alert(trybutton);
        trybutton = 'since latest dblclick: \n';
    }
}

function middleSource(){
	var ms=document.getElementById('middleSource');
	var x=Math.random();
	x=(x<0.4)?true:false;
	ms.hidden=x;
}

function useToBehand() {
    var b = document.getElementById("inBehand");
    b.style = textStyle;
}

function fly(stop){
    if (stop==0x3306 && flying){
        clearTimeout(flying);
        flying=null;
        return ;
    }
    var f=document.getElementById("fly");
    px=px+dx*0.1*parseInt(Math.random()*3);
    py=py+dy*0.15*parseInt(Math.random()*2);
    if (px>px1 ||px<px0){
        dx*=-1;
        px+=dx*0.1*3;
    }
    if (py>py1 || py<py0){
        dy*=-1;
        py=py+dy*0.15*2;
    }
    f.style="top:"+py+"%;left:"+px+"%;";
    flying=setTimeout('fly()',20);
}

function init() {
    var ed=document.getElementsByName('editable')[0];
    ed.value='捕蛇游戏: 点击逮捕乱跑的🐍;';
    var va = document.getElementsByName("textVerticalAlign")[0];
    var opt;
    for (var i = 0; i < verticalAlign.length; i++) {
        opt = document.createElement("option");
        opt.value = verticalAlign[i];
        opt.label = verticalAlign[i];
        va.appendChild(opt);
    }
    var tf = document.getElementsByName("textFont")[0];
    for (var i = 0; i < fontFamily.length; i++) {
        opt = document.createElement("option");
        opt.value = fontFamily[i];
        opt.label = fontFamily[i];
        tf.appendChild(opt);
    }
    var al = document.getElementsByName("textAlign")[0];
    for (var i = 0; i < align.length; i++) {
        opt = document.createElement("option");
        opt.value = align[i];
        opt.label = align[i];
        al.appendChild(opt);
    }
    setTime();
    fly();
}
function exit(){
    flying & clearTimeout(flying);
    timeout & clearTimeout(timeout);
}
//    x = $.ajax({url: "../else/yylj.txt", async: false});//通过ajax读取test1.txt文本文件。 
//    //$("#myDiv").html(htmlobj.responseText.replace(/.+/g, '</br>'));//根据回车换行符进行替换，替换成html换行符<br> 
//    alert(x.toLocaleString());
//if (/text+/.test(file.type)) {//判断文件类型，是不是text类型7            
//            $('body').append('<pre>' + this.result + '</pre>');
//        }
//        reader.readAsText(file);
//        reader.readAsDataURL(file);


